"""Automated tests."""
