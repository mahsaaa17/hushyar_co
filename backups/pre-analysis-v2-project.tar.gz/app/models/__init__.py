"""Domain and persistence models."""
