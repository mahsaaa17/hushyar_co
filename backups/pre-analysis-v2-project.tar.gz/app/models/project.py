"""Research project model."""
